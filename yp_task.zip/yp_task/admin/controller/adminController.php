<?php 
session_start();
require_once '../model/adminModel.php';
require_once '../model/adsModel.php';

	
	if(isset($_POST['submit']) && !empty($_POST['submit'])){
		$submit =  $_POST['submit'];
		$admin = new adminModel();
		$ads = new adsModel();
		
		if($submit == "Sign in"){
			

			$sign = $admin->signIn($_POST['email'] ,$_POST['password']);
			
			if($sign){
			header('location:../view/home.php');
			exit;
			}
		}
		
		if($submit == "log out"){
			$admin->logOut();
		}

		if($submit == "New Ads"){
			header('location:../view/AdsForm.php');
		}

		if($submit == "Add"){
			$name = "";	
			if($_FILES){
			        $tmp_name = $_FILES["file"]["tmp_name"];
			        $name = basename($_FILES["file"]["name"]);
			       	$ads->upload($tmp_name , $name);	
			}
			$adData['desc'] = $_POST['desc'] ;
			$adData['file'] = $name ;
			$check = $ads->createAds($adData);
			if($check){
				header('location:../view/home.php');
			}
		}

		if($submit == "Home"){
			
			header('location:../view/home.php');
		}

		if($submit == "Update"){
			$id = $_POST['id'];
			$adInfo = $ads->getAds($id);
			$_SESSION['ad'] = $adInfo;

			header('location:../view/updateForm.php');
		}

		if($submit == "Save"){
			$name = $_POST['oldfile'];

			if(!empty($_FILES['file']['name'])){

				if($_FILES['file']['name'] != $_POST['oldfile']){

					$tmp_name = $_FILES["file"]["tmp_name"];
			        $name = basename($_FILES["file"]["name"]);
			        $ads->unlinkFile($_POST['oldfile']);
			       	$ads->upload($tmp_name , $name);	
				}
			}
				echo $name;
				$adData['file'] = $name ;
				$adData['desc'] = $_POST['desc'];
				$adData['id']   = $_POST['id'];
				$check = $ads->updatead($adData);
			
				if($check)
					header('location:../view/home.php');
		}

		if($submit == "Confirm"){
			$id = $_POST['id'];
			$adInfo = $ads->getAds($id);
			$check = $ads->deleteAds($id);

			if($check){
				$ads->unlinkFile($adInfo[0]['file']);
				header('location:../view/home.php');
			}

		}

		#front controller
		if($submit == "All"){
			$adInfo = $ads->getAds();
		    echo json_encode($adInfo);
		}

		if($submit == "Description"){

		    $adInfo = $ads->getAds($_POST['id']);
		    $_SESSION['ad'] = $adInfo;
		 	header('location:../../view/adinfo.php');   
		}

		if($submit == "Comment"){
			$check = $ads->addComment($_POST);
			if($check){
			 	header('location:../../view/adinfo.php');
			}

			
		}
		// try {
		//   // Get the \Facebook\GraphNodes\GraphUser object for the current user.
		//   // If you provided a 'default_access_token', the '{access-token}' is optional.
		//   $response = $fb->get('/me', '{access-token}'); //access token
		// } catch(\Facebook\Exceptions\FacebookResponseException $e) {
		//   // When Graph returns an error
		//   echo 'Graph returned an error: ' . $e->getMessage();
		//   exit;
		// } catch(\Facebook\Exceptions\FacebookSDKException $e) {
		//   // When validation fails or other local issues
		//   echo 'Facebook SDK returned an error: ' . $e->getMessage();
		//   exit;
		// }

		// $me = $response->getGraphUser();
		// echo 'Logged in as ' . $me->getName();   
			
		


	}
?>