<?php 
	require_once '../../model/DB.php ';
	class Base_Model
	{
		public $db = '';
		// public $uploads_dir =
		function __construct(){

		}

		public function upload($tmp_name = "", $name = ""){
			if($tmp_name && $name){
				$dir = '../../assets/uploads';
				if(move_uploaded_file($tmp_name, "$dir/$name")){
					return true;
				}else{
					return false;
				}
			}
		}

		public function unlinkFile($name = ""){
			if($name){
				$dir = '../../assets/uploads';
				unlink("$dir/$name");
			}
		}
	
	}

?>