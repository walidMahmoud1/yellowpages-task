<?php 
	require_once 'Base_Model.php';
	class adminModel extends Base_Model
	{
		function __construct(){
			$GLOBALS['db'] = new DB();
		}
		public function signIn($email = "" , $password){
			
			$sql = "SELECT * FROM `user` WHERE `email`= '$email' and `password` = '$password'";

			$result = $GLOBALS['db']->select($sql);
			
			if($result){
				
				$_SESSION["user"][] = $result[0] ;
			}
			
			return true;
		}

		public static function logOut(){
			session_destroy();
			header('location:../view/login.php');
		}
	}
?>