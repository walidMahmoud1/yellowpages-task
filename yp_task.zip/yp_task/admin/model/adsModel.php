<?php 
	require_once 'Base_Model.php';
	class adsModel extends Base_Model
	{
		function __construct(){
			$GLOBALS['db'] = new DB();
		}
		public static function getAds($id = null){
			if($id != null){
				$sql = "SELECT * FROM `ads` Where `id` = '$id' ";
				$ad = $GLOBALS['db']->select($sql);
				return $ad;
				// var_dump($ad);
			}else{
				$sql = "SELECT * FROM `ads`";
				$allAds = $GLOBALS['db']->select($sql);
				return $allAds;
			}
			
		}

		public function createAds($adData = array()){
			if($adData){
				$desc = $adData['desc'] ;
				$file = $adData['file'] ;
				$date = date('Y-m-d h:i:s');
				$sql = "INSERT INTO `ads`VALUES ('','$desc','$file','$date')";

				$check = $GLOBALS['db']->excute($sql);
				return $check;
			}
		}

		public function updatead($adData = array()){
			if($adData){
				$desc = $adData['desc'] ;
				$file = $adData['file'] ;
				$id = $adData['id'] ;
				$date = date('Y-m-d h:i:s');
				$sql = "UPDATE `ads` SET `description`='$desc',`file`='$file',`created_at`='$date' WHERE `id` ='$id' ";
				// echo $sql;
				$check = $GLOBALS['db']->excute($sql);
				return $check;
			}	
		}

		public function deleteAds($id){
			if($id){
				$sql = "DELETE FROM `ads` WHERE `id` = '$id'";
				
				$check = $GLOBALS['db']->excute($sql);
				return $check;
			}
		}

		public function addComment($comment = array()){
			if($comment){

				$text = $comment['comment'];
				$ad_id = $comment['ad_id'];
				$guest_id = $comment['guest_id'];
				$status = 0;
				$date = date('Y-m-d h:i:s');

				$sql = "INSERT INTO `comment`(`id`, `comment`, `guest_id`, `ads_id`, `status`, `created_at`) VALUES ('','$text','$guest_id','$ad_id','$status','$date')";
				
				$check = $GLOBALS['db']->excute($sql);
				return $check;
			}
			return true;
		}

		public function getComments($cond = array()){
			$sql = "SELECT comment.id , file ,name , comment ,status FROM `comment`,ads ,guest WHERE comment.guest_id = guest.id and comment.ads_id = ads.id";

			$allComments = $GLOBALS['db']->select($sql);
			return $allComments;

		}

		public function updateComment($comment){
			if($comment){
				$id = $comment['id'];
				$status = $comment['status'];

				$sql = "UPDATE `comment` SET `status`='$status' WHERE `id`= '$id'";
				
				$check = $GLOBALS['db']->excute($sql);
				return $check; 
			}
		}
		
	}
?>