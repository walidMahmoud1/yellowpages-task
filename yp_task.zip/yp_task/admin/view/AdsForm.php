<?php require_once"template/header.php"; 
	if(isset($_SESSION['user'])){
		?>
			<div class="container-fluid">
			  <div class="row content" style="height: 1000px"><br>
			    <?php require_once"template/sidenav.php"; ?>

			    <div class="col-sm-9">
			    <br>
			     <h1>Add New Ad</h1>
			     <br>
			     <form  action="../controller/adminController.php" method="post" enctype="multipart/form-data">
				    <div class="form-group">
				      <label for="email">Image:</label>
				      <input type="file" class="form-control" name="file">
				    </div>
				    <div class="form-group">
				      <label for="desc">Description:</label>
				      <textarea name="desc" rows="4" cols="40" class="form-control" required></textarea> 
				    </div>
				    <input type="submit" name="submit" class="btn btn-default" value="Add">
				  </form>
			    </div>
			  </div>
			</div>
			<script type="text/javascript">
				$(document).ready(function() {
			    var table = $('#example').DataTable( {
			        lengthChange: false,
			        buttons: [ 'copy', 'excel', 'pdf', 'colvis' ]
			    } );
			 
			    table.buttons().container()
			        .appendTo( '#example_wrapper .col-sm-6:eq(0)' );
			} );
			</script>
			</body>
			</html>
		<?php
	}else{
		header('location:../view/login.php');
	}
?>



