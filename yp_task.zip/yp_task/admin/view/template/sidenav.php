<?php
  $root = $_SERVER['DOCUMENT_ROOT'];
 ?>
<div class="col-sm-3 " style="background-color: #f1f1f1;height: 100%;">
  <h4><?php echo $_SESSION['user'][0]['name']; ?>

<form id="logout-form" action="../controller/adminController.php" method="POST" > 
  	
  	<input type="submit" class="btn btn-link" name="submit" value="log out"></input> 
  
  </form> 
  
  <ul class="nav nav-pills nav-stacked">
    <li class="active">
    <form  action="../controller/adminController.php" method="POST" > 
    
    <input type="submit" class="btn btn-success btn-block" name="submit" value="Home" ></input> 
  
  </form>
  </li>
    
  </ul><br>
</div>