<?php
require_once '../model/adsModel.php'; 
if(isset($_SESSION['user'])){
	$ads = new adsModel();
	$allAdss = $ads->getAds();
	$dir = '../../assets/uploads';
}
?>

<form id="logout-form" action="../controller/adminController.php" method="POST" > 
  	
  	<input type="submit" class="btn btn-danger" name="submit" value="New Ads"></input> 
  
</form> <br>
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Image</th>
                <th>Description</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
        	foreach ($allAdss as $allAds) {
        ?>
			<tr>
                <td><img width="25px" height="25px" src="<?php echo $dir .'/'. $allAds['file'];?>"></td>
                <td><?php echo $allAds['description']; ?></td>
                <td>

               		<form id="logout-form" action="../controller/adminController.php" method="POST" >
               			<input type="hidden"   name="id" value="<?php echo $allAds['id']; ?>"></input>
                    <?php if($_SESSION['user'][0]['role'] != 2){ ?>
               			<button type="button" class="ad-id btn btn-danger" data-toggle="modal" data-target="#myModal"  data-id="<?php echo $allAds['id']; ?>">Delete</button> 
                    <?php  } ?>
  						      <input type="submit" class="btn btn-success" name="submit" value="Update"></input>   
					</form>

				</td>
            </tr>
        <?php

        	 } 
        ?>  
        </tbody>
        <tfoot>
            <tr>
                <th>Image</th>
                <th>Description</th>
                <th>Action</th>
            </tr>
        </tfoot>
    </table>

     <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Confirm Delete</h4>
        </div>
        <div class="modal-body">
          <p>Are you want to delete ad</p>
        </div>
        <div class="modal-footer">
          <form action="../controller/adminController.php" method="post">
          	<input type="hidden" id="adId"  name="id" value=""></input>
          	<input type="submit" class="btn btn-default" name="submit" value="Confirm"></input>
          </form>
        </div>
      </div>
    </div>
  </div>

  <script type="text/javascript">
  	$(document).on("click", ".ad-id", function () {
     var adId = $(this).data('id');
     $(".modal-footer #adId").val( adId );
     // As pointed out in comments, 
     // it is superfluous to have to manually call the modal.
     // $('#addBookDialog').modal('show');
});
  </script>