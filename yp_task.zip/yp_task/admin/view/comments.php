<?php require_once"template/header.php"; 
	if(isset($_SESSION['user'])){
		?>
			<div class="container-fluid">
			  <div class="row content" style="height: 1000px"><br>
			    <?php require_once"template/sidenav.php"; ?>

			    <div class="col-sm-9">
			    <br>
			     <?php require_once"template/commentDataTable.php"; ?>
			    </div>
			  </div>
			</div>
			<script type="text/javascript">
				$(document).ready(function() {
			    var table = $('#example').DataTable( {
			        lengthChange: false,
			        buttons: [ 'copy', 'excel', 'pdf', 'colvis' ]
			    } );
			 
			    table.buttons().container()
			        .appendTo( '#example_wrapper .col-sm-6:eq(0)' );
			} );
			</script>
			</body>
			</html>
		<?php
	}else{
		header('location:../view/login.php');
	}
