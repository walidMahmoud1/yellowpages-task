<?php
	require_once"template/header.php";
	if(isset($_SESSION['user'])){
		if(isset($_SESSION['ad'])){
			$ad = $_SESSION['ad'][0];
		}		
		?>
			<div class="container-fluid">
			  <div class="row content" style="height: 1000px"><br>
			    <?php require_once"template/sidenav.php"; ?>

			    <div class="col-sm-9">
			    <br>
			     <h1>Update Add</h1>
			     <br>
			     <form  action="../controller/adminController.php" method="post" enctype="multipart/form-data">
				    <div class="form-group">
				    	<img src="../../assets/uploads/<?php echo $ad['file']; ?>" style="width: 200px;height: 200px"><br><br>
				    	<input type="hidden" name="oldfile" value="<?php echo $ad['file']; ?>">
				    	<input type="hidden" name="id" value="<?php echo $ad['id']; ?>">
					    <label for="email">Image:</label>
					    <input type="file" class="form-control" name="file" >
				    </div>
				    <div class="form-group">
				      <label for="desc">Description:</label>
				      <textarea name="desc" rows="4" cols="40" class="form-control" required> <?php echo $ad['description']; ?></textarea> 
				    </div>
				    <input type="submit" name="submit" class="btn btn-default" value="Save">
				  </form>
			    </div>
			  </div>
			</div>
			</body>
			</html>
		<?php
	}else{
		header('location:../view/login.php');
	}
?>



