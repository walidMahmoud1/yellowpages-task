<?php require_once"../template/header.php"; ?>
<!-- <?php require_once"../template/navbar.php"; ?> -->
<body>
<div class="container">    
  <div align="center">
  	<h3>Our Product</h3><br>
  </div>
  

  <div class="" align="center">
     <img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100px%; height: 150px" alt="Image"><br>
      <div>
      <h3>Description</h3>
      <p>dsadsadsadsadsadsadsadsadasdsadsafsdgdshfdjytratyytjgjgfhd</p>
      </div>
    </div>

    <div class="" align="center">
      <div >
      	<h3>Walid Mahmoud</h3>
      </div>
      <div>
      <p>dsadsadsadsadsadsadsadsadasdsadsafsdgdshfdjytratyytjgjgfhd</p>
      </div>
    </div>
  
</div><br>
<?php require_once"../template/footer.php"; ?>