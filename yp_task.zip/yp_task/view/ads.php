<?php require_once"template/header.php"; 
	  require_once"template/navbar.php";
      require_once '../model/Ad.php';

      	$ads = new Ad();
		$allAdss = $ads->getAds();
		$dir = '../assets/uploads/';
	
?>

<body>
<div class="container text-center">    
  <h3>Our Product</h3><br>
  <div class="row" >
  	<?php foreach ($allAdss as $allAds) { ?>
  		<form action="../admin/controller/admincontroller.php" method="post">
  			<input type="hidden" name="id" value="<?php echo $allAds['id']; ?>"></input>
  		
	  		<div class='col-sm-4'>
				<img src="<?php echo $dir.$allAds['file']; ?>" class='img-responsive' style='width:100%;height:250px' alt='Image'>
				<input type="submit" class="btn btn-link btn-block" name="submit" value="Description"></input>
				<p><?php echo $allAds['description']; ?></p>
			</div>
		</form>
  	<?php }?>
  		
  </div>
</div><br>

<?php require_once"template/footer.php"; ?>

