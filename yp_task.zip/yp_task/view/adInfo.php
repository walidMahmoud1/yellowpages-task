<?php require_once"template/header.php"; ?>
<?php require_once"template/navbar.php";
      require_once '../model/Ad.php';
      require_once '../controller/config.php';

        $ads = new Ad();

$ad = $_SESSION['ad'][0];
$comments = $ads->comments(array('ads_id' => $ad['id']));
$dir = '../assets/uploads/';

$redirectURL = "http://localhost/yp_task/controller/fb_callback.php";
$permissions = ['email'];
$loginURL = $helper->getLoginUrl($redirectURL,$permissions);
?>
<body>
<div class="container ">
  <div class="text-center">   
  <h3>Our Product</h3><br>
  	<div class="" align="center">
     <img src="<?php echo $dir.$ad['file']; ?>" class="img-responsive" style="width:100px; height: 150px" alt="Image"><br>
      <div>
      <h3>Description</h3>
      <p><?php echo $ad['description']; ?></p>
      </div>
    </div>
</div> 

    <?php
      if(isset($comments) && !empty($comments)){
        foreach ($comments as$comment) {
     ?>
        <div class=""style="background-color: #ebebe0; padding: 5px; margin: 5px ">
              <div >
                <h3><?php echo $comment['name'] ; ?></h3>
                <h5><?php echo $comment['created_at'] ; ?></h5>
              </div>
              <div>
              <p style="font-weight: bold"><?php echo $comment['comment'] ; ?></p>
              </div>
            </div>
     <?php
        }
      } 
     ?>

     <div class="text-center" style="background-color: #ebebe0; padding: 10px; margin: 20px ">
       <form >
         <input type="button" onclick="window.location = '<?php echo $loginURL;?>'" value="Login With Facebook" class="btn btn-primary"></input>
       </form>

       <form action="../admin/controller/adminController.php" method="post">
          <br><textarea name="comment" class="form-control" rows="9" required></textarea><br>

          <input type="hidden" name="ad_id" value="<?php echo $ad['id'] ;?>" >

          <input type="hidden" name="guest_id" value="1" >

         <input type="submit" name="submit" value="Comment" class="btn btn-success" style=""></input>
       </form>
     </div>
    
</div><br>
<?php require_once"template/footer.php"; ?>
