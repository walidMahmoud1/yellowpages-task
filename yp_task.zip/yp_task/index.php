<?php 
  header('location:view/ads.php');
 ?>

