<?php
/**
 * 
 */
 class DB 
 {
 	private $conn ;
 	

 	function __construct(){
 		$GLOBALS['conn'] = mysqli_connect("localhost",  "root", "", "ads");

 		if (!$GLOBALS['conn']) {
   			die("Connection failed: " . mysqli_connect_error());
		}
 	}


 	public function excute($sql = "" , $last = null){
 		if($sql){
 			if (mysqli_query($GLOBALS['conn'], $sql)) {
 				if($last != null){
 					$last_id = mysqli_insert_id($GLOBALS['conn']);
    				return $last_id;
 				}else{
 					return true;	
 				}
 				
			} else {
			    return false;
			}
 		}
 	}

 	public function select($sql = ""){
 		if($sql){
 			$result = mysqli_query($GLOBALS['conn'], $sql);
 			if (mysqli_num_rows($result) > 0) {
 				 while($row = mysqli_fetch_assoc($result)) {
 				 	$data[] = $row;
 				 }
 				 return $data;
 			}
 		}
 	}

 	public function close(){
 		mysqli_close($GLOBALS['conn']);
 	}
 } 
?>