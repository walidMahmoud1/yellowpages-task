<?php 
	require_once 'DB.php';
	/**
	* 
	*/
	class Ad 
	{
		public $db;
		function __construct(){
			$GLOBALS['db'] = new DB();
		}

		public static function getAds($id = null){
			if($id != null){
				$sql = "SELECT * FROM `ads` Where `id` = '$id' ";
				$ad = $GLOBALS['db']->select($sql);
				return $ad;
				// var_dump($ad);
			}else{
				$sql = "SELECT * FROM `ads`";
				$allAds = $GLOBALS['db']->select($sql);
				return $allAds;
			}
			
		}

		public function comments($data = array()){
				$adsId = $data['ads_id'];
				$sql = "SELECT * FROM  `guest`,`comment` Where `ads_id` = '$adsId' AND `status` = 1 AND `guest_id` = guest.id  ";
				$allAds = $GLOBALS['db']->select($sql);
				return $allAds;
			
		}

	}
?>