<?php 
	require_once 'DB.php';
	/**
	* 
	*/
	class Ad 
	{
		public $db;
		function __construct(){
			$GLOBALS['db'] = new DB();
		}

		public static function getAds($id = null){
			if($id != null){
				$sql = "SELECT * FROM `ads` Where `id` = '$id' ";
				$ad = $GLOBALS['db']->select($sql);
				return $ad;
				// var_dump($ad);
			}else{
				$sql = "SELECT * FROM `ads`";
				$allAds = $GLOBALS['db']->select($sql);
				return $allAds;
			}
			
		}

		public function comments($data = array()){
			$adsId = $data['ads_id'];
			$sql = "SELECT * FROM  `guest`,`comment` Where `ads_id` = '$adsId' AND `status` = 1 AND `guest_id` = guest.id ";
			$allAds = $GLOBALS['db']->select($sql);
			return $allAds;
			
		}

		public function getGuest($data = array()){
			$email = $data['email'];
			$sql = "SELECT * FROM `guest` WHERE`email`= '$email'";
			$allAds = $GLOBALS['db']->select($sql);
			return $allAds;
			
		}

		public function addGuest($data = array()){
			$email = $data['email'];
			$name = $data['name'];
			$date = date('Y-m-d h:i:s');
			$sql = "INSERT INTO `guest`(`id`, `name`, `email`, `created_at`) VALUES ('','$name','$email','$date')";
			$allAds = $GLOBALS['db']->excute($sql);
			return $allAds;
			
		}

	}
?>