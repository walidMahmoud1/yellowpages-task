$(document).ready(function() {

	$.post( "../admin/controller/adminController.php",{ submit: "All",}, function( result ) {
			var html = "";
			var dir = "../assets/uploads/"
	  		$.each( result, function( key, value ) {
			  // console.log();
			  html +="<div class='col-sm-4'><a href='../admin/controller/adminController.php?id='"+value.id+"'>"
			  		+ "<img src='" + dir + value.file + "' class='img-responsive' "
			  		+ "style='width:100%;height:250px' alt='Image'>"
			  		+ "<h3>Description</h3><p>" + value.description + "</p></a></div>"
			});
	  		$('#ads').html(html);

		},"json");



		

});