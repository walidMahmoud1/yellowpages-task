<?php 
	require_once 'config.php';
	require_once '../model/Ad.php';

	try{
		$accessToken = $helper->getAccessToken();

		  // Get the \Facebook\GraphNodes\GraphUser object for the current user.
		  // If you provided a 'default_access_token', the '{access-token}' is optional.
		  //$response = $fb->get('/me', '{access-token}'); //access token
		} catch(\Facebook\Exceptions\FacebookResponseException $e) {
		  // When Graph returns an error
		  echo 'Graph returned an error: ' . $e->getMessage();
		  exit;
		} catch(\Facebook\Exceptions\FacebookSDKException $e) {
		  // When validation fails or other local issues
		  echo 'Facebook SDK returned an error: ' . $e->getMessage();
		  exit;
		}

		if(!$accessToken){
			header('location:../view/adinfo.php');
			exit();
		}
		
		$oAuth2Client = $fb->getOAuth2Client();
		if(!$accessToken->isLongLived()){
			$accessToken = $oAuth2Client->getLongLivedAccessToken($accessToken);
			$response = $fb->get('/me?fields=id,name,email', '{access-token}');

			$userData = $response->getGraphNode()->asArray();

			$ad = new Ad();
			$result = $ad->getGuest(array('email' => $userData['email']));

			if(!$result){
				$check = $ad->addGuest($userData);
				if($check){
					$_SESSION['userData']= $result ;
					header('location:../view/adinfo.php');
				}
			}
			
		}
?>