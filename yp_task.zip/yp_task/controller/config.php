<?php
require_once '../vendor/autoload.php';
$fb = new \Facebook\Facebook([
  'app_id' => '1688684834559865', // app id
  'app_secret' => 'cc089f15f947449d5abad02394781941', //app secret
  'default_graph_version' => 'v2.10',
  //'default_access_token' => '{access-token}', // optional
]);

// Use one of the helper classes to get a Facebook\Authentication\AccessToken entity.
$helper = $fb->getRedirectLoginHelper();
//   $helper = $fb->getJavaScriptHelper();
//   $helper = $fb->getCanvasHelper();
//   $helper = $fb->getPageTabHelper();

?>