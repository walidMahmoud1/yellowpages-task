<?php
require_once '../vendor/autoload.php';
$fb = new \Facebook\Facebook([
  'app_id' => '163307524521929', // app id
  'app_secret' => '0cfb377df3576f2543787ef0356f50d5', //app secret
  'default_graph_version' => 'v2.10',
  //'default_access_token' => '{access-token}', // optional
]);

// Use one of the helper classes to get a Facebook\Authentication\AccessToken entity.
$helper = $fb->getRedirectLoginHelper();
//   $helper = $fb->getJavaScriptHelper();
//   $helper = $fb->getCanvasHelper();
//   $helper = $fb->getPageTabHelper();

?>